import { useState } from 'react';
import { Music2 } from 'lucide-react';
import SongList from './components/SongList';
import ServiceList from './components/ServiceList';
import MusicianList from './components/MusicianList';
import Reports from './components/Reports';

type Tab = 'songs' | 'services' | 'musicians' | 'reports';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('services');

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-3">
            <Music2 className="w-8 h-8 text-blue-600" />
            <h1 className="text-2xl font-bold text-gray-900">EscalaCanto</h1>
          </div>
          <p className="text-sm text-gray-600 mt-1">
            Worship Service Scheduling System
          </p>
        </div>
      </header>

      <nav className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex gap-1">
            <button
              onClick={() => setActiveTab('services')}
              className={`px-4 py-3 font-medium transition-colors border-b-2 ${
                activeTab === 'services'
                  ? 'border-green-600 text-green-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              Services
            </button>
            <button
              onClick={() => setActiveTab('songs')}
              className={`px-4 py-3 font-medium transition-colors border-b-2 ${
                activeTab === 'songs'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              Songs
            </button>
            <button
              onClick={() => setActiveTab('musicians')}
              className={`px-4 py-3 font-medium transition-colors border-b-2 ${
                activeTab === 'musicians'
                  ? 'border-orange-600 text-orange-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              Team
            </button>
            <button
              onClick={() => setActiveTab('reports')}
              className={`px-4 py-3 font-medium transition-colors border-b-2 ${
                activeTab === 'reports'
                  ? 'border-red-600 text-red-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              Reports
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeTab === 'songs' && <SongList />}
        {activeTab === 'services' && <ServiceList />}
        {activeTab === 'musicians' && <MusicianList />}
        {activeTab === 'reports' && <Reports />}
      </main>
    </div>
  );
}

export default App;
