import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
  throw new Error('Missing Supabase environment variables');
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export interface Song {
  id: string;
  name: string;
  version: string;
  key: string;
  chord_sheet: string;
  play_count: number;
  created_at: string;
  updated_at: string;
}

export interface Service {
  id: string;
  service_date: string;
  worship_leader: string;
  notes: string;
  created_at: string;
  updated_at: string;
}

export interface Musician {
  id: string;
  name: string;
  instrument: string;
  phone: string;
  created_at: string;
}

export interface ServiceSong {
  id: string;
  service_id: string;
  song_id: string;
  order_position: number;
  created_at: string;
  songs?: Song;
}

export interface ServiceParticipant {
  id: string;
  service_id: string;
  musician_id: string;
  role: 'singer' | 'musician' | 'worship_leader';
  created_at: string;
  musicians?: Musician;
}
