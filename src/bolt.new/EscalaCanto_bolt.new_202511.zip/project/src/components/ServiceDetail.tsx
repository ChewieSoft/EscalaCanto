import { useState, useEffect } from 'react';
import { supabase, Service, ServiceSong, ServiceParticipant } from '../lib/supabase';
import { X, Share2 } from 'lucide-react';

interface ServiceDetailProps {
  service: Service;
  onClose: () => void;
}

export default function ServiceDetail({ service, onClose }: ServiceDetailProps) {
  const [songs, setSongs] = useState<ServiceSong[]>([]);
  const [participants, setParticipants] = useState<ServiceParticipant[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchServiceDetails();
  }, [service.id]);

  const fetchServiceDetails = async () => {
    setLoading(true);

    const { data: songsData } = await supabase
      .from('service_songs')
      .select('*, songs(*)')
      .eq('service_id', service.id)
      .order('order_position');

    const { data: participantsData } = await supabase
      .from('service_participants')
      .select('*, musicians(*)')
      .eq('service_id', service.id);

    setSongs(songsData || []);
    setParticipants(participantsData || []);
    setLoading(false);
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleShare = () => {
    const message = generateWhatsAppMessage();
    const encodedMessage = encodeURIComponent(message);
    window.open(`https://wa.me/?text=${encodedMessage}`, '_blank');
  };

  const generateWhatsAppMessage = () => {
    let message = `*Worship Service Schedule*\n\n`;
    message += `📅 *Date:* ${formatDate(service.service_date)}\n\n`;

    if (service.worship_leader) {
      message += `🎤 *Worship Leader:* ${service.worship_leader}\n\n`;
    }

    if (songs.length > 0) {
      message += `*🎵 Song List:*\n`;
      songs.forEach((serviceSong, index) => {
        const song = serviceSong.songs;
        if (song) {
          message += `${index + 1}. ${song.name}`;
          if (song.version) message += ` (${song.version})`;
          if (song.key) message += ` - Key: ${song.key}`;
          message += '\n';
        }
      });
      message += '\n';
    }

    if (participants.length > 0) {
      message += `*👥 Team:*\n`;
      const singers = participants.filter(p => p.role === 'singer');
      const musicians = participants.filter(p => p.role === 'musician');

      if (singers.length > 0) {
        message += `Singers: ${singers.map(p => p.musicians?.name).join(', ')}\n`;
      }
      if (musicians.length > 0) {
        message += `Musicians: ${musicians.map(p => p.musicians?.name).join(', ')}\n`;
      }
    }

    if (service.notes) {
      message += `\n📝 *Notes:* ${service.notes}`;
    }

    return message;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <h3 className="text-xl font-bold text-gray-800">Service Details</h3>
          <div className="flex gap-2">
            <button
              onClick={handleShare}
              className="p-2 text-green-600 hover:bg-green-50 rounded transition-colors"
              title="Share via WhatsApp"
            >
              <Share2 className="w-5 h-5" />
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="p-6 space-y-6">
          <div>
            <h4 className="text-lg font-semibold text-gray-800 mb-2">
              {formatDate(service.service_date)}
            </h4>
            {service.worship_leader && (
              <p className="text-gray-700">
                <strong>Worship Leader:</strong> {service.worship_leader}
              </p>
            )}
            {service.notes && (
              <p className="text-gray-600 mt-2">{service.notes}</p>
            )}
          </div>

          {loading ? (
            <div className="text-center py-8">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-gray-300 border-t-green-600"></div>
            </div>
          ) : (
            <>
              {songs.length > 0 && (
                <div>
                  <h5 className="font-semibold text-gray-800 mb-3">Song List</h5>
                  <div className="space-y-2">
                    {songs.map((serviceSong, index) => {
                      const song = serviceSong.songs;
                      return (
                        <div
                          key={serviceSong.id}
                          className="bg-gray-50 p-3 rounded"
                        >
                          <div className="flex items-start gap-3">
                            <span className="font-semibold text-gray-600">
                              {index + 1}.
                            </span>
                            <div className="flex-1">
                              <p className="font-medium text-gray-800">
                                {song?.name}
                              </p>
                              <div className="flex gap-3 text-sm text-gray-600 mt-1">
                                {song?.version && (
                                  <span>Version: {song.version}</span>
                                )}
                                {song?.key && <span>Key: {song.key}</span>}
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {participants.length > 0 && (
                <div>
                  <h5 className="font-semibold text-gray-800 mb-3">
                    Team Members
                  </h5>
                  <div className="space-y-2">
                    {['singer', 'musician'].map(role => {
                      const roleParticipants = participants.filter(
                        p => p.role === role
                      );
                      if (roleParticipants.length === 0) return null;

                      return (
                        <div key={role} className="bg-gray-50 p-3 rounded">
                          <p className="font-medium text-gray-700 mb-1 capitalize">
                            {role}s:
                          </p>
                          <p className="text-gray-600">
                            {roleParticipants
                              .map(p => p.musicians?.name)
                              .join(', ')}
                          </p>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
