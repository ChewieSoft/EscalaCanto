import { useState, useEffect } from 'react';
import { supabase, Song } from '../lib/supabase';
import { Music, Plus, Search, Edit2, Trash2 } from 'lucide-react';
import SongForm from './SongForm';

export default function SongList() {
  const [songs, setSongs] = useState<Song[]>([]);
  const [filteredSongs, setFilteredSongs] = useState<Song[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showForm, setShowForm] = useState(false);
  const [editingSong, setEditingSong] = useState<Song | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchSongs();
  }, []);

  useEffect(() => {
    if (searchQuery.trim() === '') {
      setFilteredSongs(songs);
    } else {
      const query = searchQuery.toLowerCase();
      setFilteredSongs(
        songs.filter(
          song =>
            song.name.toLowerCase().includes(query) ||
            song.version.toLowerCase().includes(query)
        )
      );
    }
  }, [searchQuery, songs]);

  const fetchSongs = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('songs')
      .select('*')
      .order('name');

    if (error) {
      console.error('Error fetching songs:', error);
    } else {
      setSongs(data || []);
    }
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this song?')) return;

    const { error } = await supabase.from('songs').delete().eq('id', id);

    if (error) {
      console.error('Error deleting song:', error);
      alert('Error deleting song');
    } else {
      fetchSongs();
    }
  };

  const handleEdit = (song: Song) => {
    setEditingSong(song);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingSong(null);
    fetchSongs();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Music className="w-8 h-8 text-blue-600" />
          <h2 className="text-2xl font-bold text-gray-800">Song Library</h2>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Add Song
        </button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
        <input
          type="text"
          placeholder="Search songs by name or version..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        />
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-gray-300 border-t-blue-600"></div>
        </div>
      ) : filteredSongs.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          {searchQuery ? 'No songs found' : 'No songs yet. Add your first song!'}
        </div>
      ) : (
        <div className="grid gap-4">
          {filteredSongs.map(song => (
            <div
              key={song.id}
              className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-800">
                    {song.name}
                  </h3>
                  <div className="flex gap-4 mt-2 text-sm text-gray-600">
                    {song.version && (
                      <span>
                        <strong>Version:</strong> {song.version}
                      </span>
                    )}
                    {song.key && (
                      <span>
                        <strong>Key:</strong> {song.key}
                      </span>
                    )}
                    <span>
                      <strong>Played:</strong> {song.play_count} times
                    </span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEdit(song)}
                    className="p-2 text-blue-600 hover:bg-blue-50 rounded transition-colors"
                  >
                    <Edit2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDelete(song.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <SongForm song={editingSong} onClose={handleCloseForm} />
      )}
    </div>
  );
}
