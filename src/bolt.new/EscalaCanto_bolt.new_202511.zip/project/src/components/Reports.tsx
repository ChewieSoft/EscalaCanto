import { useState, useEffect } from 'react';
import { supabase, Song } from '../lib/supabase';
import { BarChart3 } from 'lucide-react';

export default function Reports() {
  const [topSongs, setTopSongs] = useState<Song[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTopSongs();
  }, []);

  const fetchTopSongs = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('songs')
      .select('*')
      .order('play_count', { ascending: false })
      .limit(10);

    if (error) {
      console.error('Error fetching top songs:', error);
    } else {
      setTopSongs(data || []);
    }
    setLoading(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <BarChart3 className="w-8 h-8 text-red-600" />
        <h2 className="text-2xl font-bold text-gray-800">Reports</h2>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">
          Top 10 Most Played Songs
        </h3>

        {loading ? (
          <div className="text-center py-8">
            <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-gray-300 border-t-red-600"></div>
          </div>
        ) : topSongs.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            No songs have been played yet.
          </div>
        ) : (
          <div className="space-y-3">
            {topSongs.map((song, index) => (
              <div
                key={song.id}
                className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
              >
                <div className="flex items-center gap-4 flex-1">
                  <span className="text-2xl font-bold text-gray-400 w-8 text-center">
                    {index + 1}
                  </span>
                  <div>
                    <p className="font-medium text-gray-800">{song.name}</p>
                    {song.version && (
                      <p className="text-sm text-gray-600">{song.version}</p>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold text-red-600">
                    {song.play_count}
                  </p>
                  <p className="text-xs text-gray-500">times played</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
