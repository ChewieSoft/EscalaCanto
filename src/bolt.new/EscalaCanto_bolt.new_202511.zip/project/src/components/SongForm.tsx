import { useState, useEffect } from 'react';
import { supabase, Song } from '../lib/supabase';
import { X } from 'lucide-react';

interface SongFormProps {
  song: Song | null;
  onClose: () => void;
}

export default function SongForm({ song, onClose }: SongFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    version: '',
    key: '',
    chord_sheet: '',
  });
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (song) {
      setFormData({
        name: song.name,
        version: song.version,
        key: song.key,
        chord_sheet: song.chord_sheet,
      });
    }
  }, [song]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      if (song) {
        const { error } = await supabase
          .from('songs')
          .update({ ...formData, updated_at: new Date().toISOString() })
          .eq('id', song.id);

        if (error) throw error;
      } else {
        const { error } = await supabase.from('songs').insert([formData]);

        if (error) throw error;
      }

      onClose();
    } catch (error) {
      console.error('Error saving song:', error);
      alert('Error saving song');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <h3 className="text-xl font-bold text-gray-800">
            {song ? 'Edit Song' : 'Add New Song'}
          </h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Song Name *
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={e => setFormData({ ...formData, name: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Version / Performer
            </label>
            <input
              type="text"
              value={formData.version}
              onChange={e =>
                setFormData({ ...formData, version: e.target.value })
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Musical Key
            </label>
            <input
              type="text"
              value={formData.key}
              onChange={e => setFormData({ ...formData, key: e.target.value })}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="e.g., C, D, Em"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Chord Sheet
            </label>
            <textarea
              rows={10}
              value={formData.chord_sheet}
              onChange={e =>
                setFormData({ ...formData, chord_sheet: e.target.value })
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
              placeholder="Paste chord sheet here..."
            />
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              disabled={saving}
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 transition-colors"
            >
              {saving ? 'Saving...' : song ? 'Update Song' : 'Add Song'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
