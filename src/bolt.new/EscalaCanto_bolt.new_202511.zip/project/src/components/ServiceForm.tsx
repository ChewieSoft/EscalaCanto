import { useState, useEffect } from 'react';
import { supabase, Song, Musician } from '../lib/supabase';
import { X, Plus, Trash2 } from 'lucide-react';

interface ServiceFormProps {
  onClose: () => void;
}

export default function ServiceForm({ onClose }: ServiceFormProps) {
  const [formData, setFormData] = useState({
    service_date: '',
    worship_leader: '',
    notes: '',
  });
  const [songs, setSongs] = useState<Song[]>([]);
  const [musicians, setMusicians] = useState<Musician[]>([]);
  const [selectedSongs, setSelectedSongs] = useState<string[]>([]);
  const [selectedParticipants, setSelectedParticipants] = useState<
    Array<{ musician_id: string; role: string }>
  >([]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSongs();
    fetchMusicians();
  }, []);

  const fetchSongs = async () => {
    const { data } = await supabase.from('songs').select('*').order('name');
    setSongs(data || []);
  };

  const fetchMusicians = async () => {
    const { data } = await supabase.from('musicians').select('*').order('name');
    setMusicians(data || []);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);

    try {
      const { data: service, error: serviceError } = await supabase
        .from('services')
        .insert([formData])
        .select()
        .single();

      if (serviceError) throw serviceError;

      const serviceSongsData = selectedSongs.map((songId, index) => ({
        service_id: service.id,
        song_id: songId,
        order_position: index,
      }));

      if (serviceSongsData.length > 0) {
        const { error: songsError } = await supabase
          .from('service_songs')
          .insert(serviceSongsData);

        if (songsError) throw songsError;

        const songIds = selectedSongs;
        for (const songId of songIds) {
          await supabase.rpc('increment', {
            row_id: songId,
          }).catch(() => {
            supabase
              .from('songs')
              .select('play_count')
              .eq('id', songId)
              .single()
              .then(({ data }) => {
                if (data) {
                  supabase
                    .from('songs')
                    .update({ play_count: (data.play_count || 0) + 1 })
                    .eq('id', songId);
                }
              });
          });
        }
      }

      if (selectedParticipants.length > 0) {
        const participantsData = selectedParticipants.map(p => ({
          service_id: service.id,
          musician_id: p.musician_id,
          role: p.role,
        }));

        const { error: participantsError } = await supabase
          .from('service_participants')
          .insert(participantsData);

        if (participantsError) throw participantsError;
      }

      onClose();
    } catch (error) {
      console.error('Error creating service:', error);
      alert('Error creating service');
    } finally {
      setSaving(false);
    }
  };

  const addSong = (songId: string) => {
    if (!selectedSongs.includes(songId)) {
      setSelectedSongs([...selectedSongs, songId]);
    }
  };

  const removeSong = (songId: string) => {
    setSelectedSongs(selectedSongs.filter(id => id !== songId));
  };

  const addParticipant = () => {
    setSelectedParticipants([
      ...selectedParticipants,
      { musician_id: '', role: 'musician' },
    ]);
  };

  const removeParticipant = (index: number) => {
    setSelectedParticipants(selectedParticipants.filter((_, i) => i !== index));
  };

  const updateParticipant = (
    index: number,
    field: string,
    value: string
  ) => {
    const updated = [...selectedParticipants];
    updated[index] = { ...updated[index], [field]: value };
    setSelectedParticipants(updated);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl w-full max-w-3xl max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between p-6 border-b">
          <h3 className="text-xl font-bold text-gray-800">Create Service</h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-gray-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Service Date & Time *
            </label>
            <input
              type="datetime-local"
              required
              value={formData.service_date}
              onChange={e =>
                setFormData({ ...formData, service_date: e.target.value })
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Worship Leader
            </label>
            <input
              type="text"
              value={formData.worship_leader}
              onChange={e =>
                setFormData({ ...formData, worship_leader: e.target.value })
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Notes
            </label>
            <textarea
              rows={3}
              value={formData.notes}
              onChange={e =>
                setFormData({ ...formData, notes: e.target.value })
              }
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Songs
            </label>
            <select
              onChange={e => {
                addSong(e.target.value);
                e.target.value = '';
              }}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent mb-2"
            >
              <option value="">Select a song...</option>
              {songs.map(song => (
                <option key={song.id} value={song.id}>
                  {song.name} {song.version && `(${song.version})`}
                </option>
              ))}
            </select>
            <div className="space-y-2">
              {selectedSongs.map((songId, index) => {
                const song = songs.find(s => s.id === songId);
                return (
                  <div
                    key={songId}
                    className="flex items-center justify-between bg-gray-50 p-3 rounded"
                  >
                    <span>
                      {index + 1}. {song?.name}
                    </span>
                    <button
                      type="button"
                      onClick={() => removeSong(songId)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="block text-sm font-medium text-gray-700">
                Team Members
              </label>
              <button
                type="button"
                onClick={addParticipant}
                className="text-sm text-green-600 hover:text-green-700 flex items-center gap-1"
              >
                <Plus className="w-4 h-4" />
                Add Member
              </button>
            </div>
            <div className="space-y-2">
              {selectedParticipants.map((participant, index) => (
                <div key={index} className="flex gap-2">
                  <select
                    value={participant.musician_id}
                    onChange={e =>
                      updateParticipant(index, 'musician_id', e.target.value)
                    }
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="">Select member...</option>
                    {musicians.map(musician => (
                      <option key={musician.id} value={musician.id}>
                        {musician.name}
                      </option>
                    ))}
                  </select>
                  <select
                    value={participant.role}
                    onChange={e =>
                      updateParticipant(index, 'role', e.target.value)
                    }
                    className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                  >
                    <option value="musician">Musician</option>
                    <option value="singer">Singer</option>
                    <option value="worship_leader">Worship Leader</option>
                  </select>
                  <button
                    type="button"
                    onClick={() => removeParticipant(index)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              ))}
            </div>
          </div>

          <div className="flex gap-3 pt-4">
            <button
              type="submit"
              disabled={saving}
              className="flex-1 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 disabled:bg-gray-400 transition-colors"
            >
              {saving ? 'Creating...' : 'Create Service'}
            </button>
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300 transition-colors"
            >
              Cancel
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
