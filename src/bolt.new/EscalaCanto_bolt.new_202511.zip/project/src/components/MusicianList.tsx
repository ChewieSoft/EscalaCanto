import { useState, useEffect } from 'react';
import { supabase, Musician } from '../lib/supabase';
import { Users, Plus, Edit2, Trash2 } from 'lucide-react';
import MusicianForm from './MusicianForm';

export default function MusicianList() {
  const [musicians, setMusicians] = useState<Musician[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingMusician, setEditingMusician] = useState<Musician | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchMusicians();
  }, []);

  const fetchMusicians = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('musicians')
      .select('*')
      .order('name');

    if (error) {
      console.error('Error fetching musicians:', error);
    } else {
      setMusicians(data || []);
    }
    setLoading(false);
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Are you sure you want to delete this musician?')) return;

    const { error } = await supabase.from('musicians').delete().eq('id', id);

    if (error) {
      console.error('Error deleting musician:', error);
      alert('Error deleting musician');
    } else {
      fetchMusicians();
    }
  };

  const handleEdit = (musician: Musician) => {
    setEditingMusician(musician);
    setShowForm(true);
  };

  const handleCloseForm = () => {
    setShowForm(false);
    setEditingMusician(null);
    fetchMusicians();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Users className="w-8 h-8 text-orange-600" />
          <h2 className="text-2xl font-bold text-gray-800">Team Members</h2>
        </div>
        <button
          onClick={() => setShowForm(true)}
          className="flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors"
        >
          <Plus className="w-5 h-5" />
          Add Member
        </button>
      </div>

      {loading ? (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-gray-300 border-t-orange-600"></div>
        </div>
      ) : musicians.length === 0 ? (
        <div className="text-center py-12 text-gray-500">
          No team members yet. Add your first member!
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2">
          {musicians.map(musician => (
            <div
              key={musician.id}
              className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-800">
                    {musician.name}
                  </h3>
                  <div className="space-y-1 mt-2 text-sm text-gray-600">
                    {musician.instrument && (
                      <p>
                        <strong>Instrument:</strong> {musician.instrument}
                      </p>
                    )}
                    {musician.phone && (
                      <p>
                        <strong>Phone:</strong> {musician.phone}
                      </p>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => handleEdit(musician)}
                    className="p-2 text-orange-600 hover:bg-orange-50 rounded transition-colors"
                  >
                    <Edit2 className="w-5 h-5" />
                  </button>
                  <button
                    onClick={() => handleDelete(musician.id)}
                    className="p-2 text-red-600 hover:bg-red-50 rounded transition-colors"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {showForm && (
        <MusicianForm musician={editingMusician} onClose={handleCloseForm} />
      )}
    </div>
  );
}
