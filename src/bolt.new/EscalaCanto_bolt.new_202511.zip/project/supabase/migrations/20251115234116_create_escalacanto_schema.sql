/*
  # EscalaCanto Database Schema
  
  ## Overview
  Complete database schema for the EscalaCanto worship service scheduling system.
  
  ## New Tables
  
  ### `songs`
  - `id` (uuid, primary key)
  - `name` (text) - Song name
  - `version` (text) - Performer/version
  - `key` (text) - Musical key
  - `chord_sheet` (text) - Chord sheet content
  - `play_count` (integer) - Number of times played
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)
  
  ### `services`
  - `id` (uuid, primary key)
  - `service_date` (timestamptz) - Date and time of service
  - `worship_leader` (text) - Name of worship leader
  - `notes` (text) - Additional notes
  - `created_at` (timestamptz)
  - `updated_at` (timestamptz)
  
  ### `service_songs`
  - `id` (uuid, primary key)
  - `service_id` (uuid, foreign key) - References services
  - `song_id` (uuid, foreign key) - References songs
  - `order_position` (integer) - Order in the service
  - `created_at` (timestamptz)
  
  ### `musicians`
  - `id` (uuid, primary key)
  - `name` (text) - Musician name
  - `instrument` (text) - Instrument they play
  - `phone` (text) - Phone number for WhatsApp
  - `created_at` (timestamptz)
  
  ### `service_participants`
  - `id` (uuid, primary key)
  - `service_id` (uuid, foreign key) - References services
  - `musician_id` (uuid, foreign key) - References musicians
  - `role` (text) - Role: 'singer', 'musician', 'worship_leader'
  - `created_at` (timestamptz)
  
  ## Security
  - Enable RLS on all tables
  - Add policies for authenticated users to manage all records
  
  ## Indexes
  - Index on song names for quick search
  - Index on service dates for chronological queries
  - Index on play_count for reports
*/

CREATE TABLE IF NOT EXISTS songs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  version text DEFAULT '',
  key text DEFAULT '',
  chord_sheet text DEFAULT '',
  play_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_date timestamptz NOT NULL,
  worship_leader text DEFAULT '',
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS service_songs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid NOT NULL REFERENCES services(id) ON DELETE CASCADE,
  song_id uuid NOT NULL REFERENCES songs(id) ON DELETE CASCADE,
  order_position integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  UNIQUE(service_id, song_id)
);

CREATE TABLE IF NOT EXISTS musicians (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  instrument text DEFAULT '',
  phone text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS service_participants (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  service_id uuid NOT NULL REFERENCES services(id) ON DELETE CASCADE,
  musician_id uuid NOT NULL REFERENCES musicians(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'musician',
  created_at timestamptz DEFAULT now(),
  UNIQUE(service_id, musician_id)
);

CREATE INDEX IF NOT EXISTS idx_songs_name ON songs(name);
CREATE INDEX IF NOT EXISTS idx_songs_play_count ON songs(play_count DESC);
CREATE INDEX IF NOT EXISTS idx_services_date ON services(service_date DESC);

ALTER TABLE songs ENABLE ROW LEVEL SECURITY;
ALTER TABLE services ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_songs ENABLE ROW LEVEL SECURITY;
ALTER TABLE musicians ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_participants ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view songs"
  ON songs FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can insert songs"
  ON songs FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update songs"
  ON songs FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete songs"
  ON songs FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can view services"
  ON services FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can insert services"
  ON services FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Authenticated users can update services"
  ON services FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete services"
  ON services FOR DELETE
  TO authenticated
  USING (true);

CREATE POLICY "Anyone can view service_songs"
  ON service_songs FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can manage service_songs"
  ON service_songs FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can view musicians"
  ON musicians FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can manage musicians"
  ON musicians FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Anyone can view service_participants"
  ON service_participants FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can manage service_participants"
  ON service_participants FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);